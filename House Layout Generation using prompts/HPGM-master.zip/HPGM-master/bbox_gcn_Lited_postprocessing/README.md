## Intelligent Home 3D: Automatic 3D-House Design from Linguistic Descriptions Only

* (Description)

### Architecture of Network

### Requirements

* python2.7
* Pytorch0.4

### Training

```python
python main.py --cfg cfg/layout.yml --gpu '0'
```

### Testing

```python
python main.py --cfg cfg/layout_test.yml --gpu '0'
```

